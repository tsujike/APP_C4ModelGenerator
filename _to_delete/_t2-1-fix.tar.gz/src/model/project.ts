/**
 * 表示レベルへのエッジ射影・集約(設計書 docs/02_アーキテクチャ設計書.md §6、FR-5.8)。
 * `model/` はDOM非依存の純関数のみで構成する(実装指示書§4)。
 */

import type { C4Edge, C4Model, C4Node, Level } from './types';

/** 射影・集約後の1本の描画用エッジ。 */
export interface ProjectedEdge {
  from: string; // 射影後の起点alias(表示レベルで可視な最深祖先)
  to: string;
  label?: string; // 代表エッジのラベル。集約数が2以上なら末尾に ` (+k)` を付与済み(§6-4)
  technology?: string; // 代表エッジ(§6-4のラベル選択と同じ規則で選ぶ)のtechnology
  bidirectional: boolean;
  /** このエッジに集約された元エッジ(model.edges)の本数。1なら集約なし。 */
  mergedCount: number;
}

export interface ProjectedGraph {
  level: Level;
  edges: ProjectedEdge[];
}

/** 射影後の (from, to, bidirectional) をキーに集約する際の作業用バケット。 */
interface EdgeGroup {
  from: string;
  to: string;
  bidirectional: boolean;
  members: C4Edge[];
}

/**
 * C4Model の全エッジを表示レベル `level` に射影・集約する(設計書§6)。
 *
 * 1. 各エッジの from/to を、自身を含む祖先チェーンを根方向に辿り、「boundaryノードではなく、
 *    かつ level(このノードが登場するレベル) <= 表示レベル」を満たす最初のノードへ射影する
 *    (= 可視な最深祖先。boundaryノードは§4のとおりエッジ射影の射影先にならないため、
 *    祖先探索時は読み飛ばして更に上を辿る)。
 * 2. 射影後に from === to になったエッジ(同一の折りたたみノード内部の関係)は捨てる。
 * 3. 射影後の (from, to, bidirectional) が同じエッジ群を1本に集約する。代表ラベル/technologyは
 *    「declaredLevel が表示レベルに最も近い(|declaredLevel-level|最小、同値なら浅い=declaredLevelが
 *    小さい方)」エッジのものを使い、集約数が2以上ならラベル末尾に ` (+k)` を付ける
 *    (k=集約された他エッジ数)。
 *
 * 出力の並び順は、各集約グループの先頭(最初に登場した元エッジ)が model.edges 中に現れた順。
 */
export function project(model: C4Model, level: Level): ProjectedGraph {
  const groups = new Map<string, EdgeGroup>();
  const order: string[] = [];

  for (const edge of model.edges) {
    const from = findProjectionTarget(edge.from, model.byAlias, level);
    const to = findProjectionTarget(edge.to, model.byAlias, level);
    // 可視な祖先が見つからない場合(boundaryノード自身がRelの端点に書かれた等の想定外入力)は
    // 射影のしようが無いため、このエッジは描画対象から外す(§6, edge-case)。
    if (from === undefined || to === undefined) continue;
    // 射影後に同一ノード内部の関係になったエッジは捨てる(§6-3)。
    if (from === to) continue;

    const key = `${from} ${to} ${String(edge.bidirectional)}`;
    const group = groups.get(key);
    if (group === undefined) {
      groups.set(key, { from, to, bidirectional: edge.bidirectional, members: [edge] });
      order.push(key);
    } else {
      group.members.push(edge);
    }
  }

  const edges = order.map((key) => {
    const group = groups.get(key);
    // order は groups.set と同時にしか push しないため、対応するエントリは必ず存在する。
    if (group === undefined) throw new Error('unreachable: projected edge group not found');
    return buildProjectedEdge(group, level);
  });

  return { level, edges };
}

/**
 * alias から、自身を含む祖先チェーンを根方向に辿り、boundaryではなく level 以下の
 * 最初のノードのaliasを返す(§6の「可視な最深祖先」)。
 * 見つからなければ undefined(祖先チェーンがboundaryノードで尽きた場合の保険。§4参照)。
 */
function findProjectionTarget(
  alias: string,
  byAlias: ReadonlyMap<string, C4Node>,
  level: Level,
): string | undefined {
  let node: C4Node | undefined = byAlias.get(alias);
  while (node !== undefined) {
    if (node.kind !== 'boundary' && node.level <= level) {
      return node.alias;
    }
    node = node.parent;
  }
  return undefined;
}

/** 集約グループから1本のProjectedEdgeを組み立てる(代表ラベル選択+`(+k)`表記、§6-4)。 */
function buildProjectedEdge(group: EdgeGroup, level: Level): ProjectedEdge {
  const representative = pickRepresentative(group.members, level);
  const extraCount = group.members.length - 1;
  const label =
    extraCount >= 1
      ? representative.label !== undefined
        ? `${representative.label} (+${extraCount})`
        : `(+${extraCount})`
      : representative.label;

  return {
    from: group.from,
    to: group.to,
    bidirectional: group.bidirectional,
    mergedCount: group.members.length,
    ...(label !== undefined ? { label } : {}),
    ...(representative.technology !== undefined ? { technology: representative.technology } : {}),
  };
}

/**
 * declaredLevel が表示レベルに最も近い(同値なら浅い=declaredLevelが小さい方)エッジを選ぶ(§6-4)。
 * 完全に同値(declaredLevelも同じ)な場合は、model.edges中で先に現れたものを採用する
 * (仕様に明記が無いため、宣言順を優先する最単純解釈)。
 */
function pickRepresentative(members: readonly C4Edge[], level: Level): C4Edge {
  let best = members[0];
  if (best === undefined) throw new Error('unreachable: empty edge group');
  for (let i = 1; i < members.length; i++) {
    const candidate = members[i];
    if (candidate !== undefined && isCloser(candidate, best, level)) {
      best = candidate;
    }
  }
  return best;
}

function isCloser(candidate: C4Edge, current: C4Edge, level: Level): boolean {
  const candidateDiff = Math.abs(candidate.declaredLevel - level);
  const currentDiff = Math.abs(current.declaredLevel - level);
  if (candidateDiff !== currentDiff) return candidateDiff < currentDiff;
  return candidate.declaredLevel < current.declaredLevel;
}
